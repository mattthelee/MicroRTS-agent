strategychooser folder should be placed in the the src/ai folder within microrts. To initialise, please use the following:
new QMLeeSaundersHind(utt);
This will run strategyChooser with its default(optimised) settings
